
🐹 CHIIKAWA QUÍMICA WEB PACK 🧪

Tu proyecto está casi listo, pero necesitas colocar manualmente los GIFs en la carpeta: /img

1. Descarga los siguientes GIFs desde Tenor.com (ver links en ChatGPT)
2. Guárdalos con los siguientes nombres dentro de la carpeta 'img':

   - chiikawa-party.gif
   - chiikawa-cute.gif
   - chiikawa-usagi-smile.gif
   - chiikawa-look.gif
   - chiikawa-hug.gif
   - hachiware-hachiwarechiikawa.gif
   - bow-pink.gif

3. Sube todo a tu repo de GitHub y listo 💖

¡Ánimo Sodo! Esto ya va que vuela 🌸
